I want to... 

- Embed tasks from my task manager: [[Syncing and Embedding Tasks with Todoist]]
- Take good meeting notes in Obsidian [[Meeting Notes in Obsidian]]
- Timblock my day in Obsidian: [[Timeblocking in Obsidian]]