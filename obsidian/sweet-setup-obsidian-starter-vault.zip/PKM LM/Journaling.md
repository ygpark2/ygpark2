I want to...

- Set up Daily Questions: [[Daily Questions in Obsidian]]
- Add entries from anywhere in Obsidian: [[Journaling in Obsidian with QuickAdd]]