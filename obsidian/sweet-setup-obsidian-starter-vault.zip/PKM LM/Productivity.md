I want to...

- Use templates: [[Using Templates in Obsidian]]
- Set up keyboard shortcuts: [[Keyboard Hotkeys and The Command Pallette]]
- Use the Graph view: [[The Power of the Local Graph]]
- Leverage callback URLs: [[Callback URLs in Obsidian]]
- Split text into separate notes: [[Splitting Notes in Obsidian]]
- Leverage metadata to organize my motes: [[YAML & Dataview]]