I want to...

- Understand Personal Knowledge Management (PKM) better: [[Intro to Personal Knowledge Management]]
- Understand the differences between Obsidian and Roam Research: [[Obsidian vs. Roam Research]]
- Make better use of my notes: [[Note-Taking vs. Note-Making]]
- Figure out how to connect and transclude notes [[Connecting Notes & Bidirectional Linking]]
- Read about how Nick Milo applies intentionality to his technology: [[Nick Milo's Mindfulness Monday Interview]]