I want to...

- Make Obsidian feel more like Ulysses: [[Turning Obsidian into the Perfect Writing App]]
- Manage writing projects with kanban boards: [[Mike's Obsidian-Based Writing Workflow]]